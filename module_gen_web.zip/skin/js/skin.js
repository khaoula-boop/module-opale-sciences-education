// Skin specific Javascript
if ("scImageMgr" in window) scImageMgr.fOverAlpha=.9;
tplMgr.fZenBtnPath = "bod:.default/ide:navigation/chi:menu";
tplMgr.fDysOptions.defaultPanelInactive = false;